// app.js

// --- Mock Data: Now using direct placeholder URLs for easy editing ---
const postsData = [
    {
        id: 1,
        title: "Sunset at Panambur Beach",
        author: "Swayam S Rai (Blogger)",
        date: "Nov 15 2025",
        excerpt: "The golden hour at Panambur is simply magical. Here are my best tips for capturing the perfect sunset photograph, avoiding the crowds, and finding the best street food near the beach...",
        category: "Beaches",
        // Direct URL is now in the 'img' property: easily editable!weDQ1MHgxMDAt/MDBmMHcwMTBjMDEx/cjExMGYxMTByMDEw/dDAxMC5qcGct/NjAweDQ1MHgxMDAt/MDBmMHcwMTBjMDEx/cjExMGYxMTByMDEw/dDAxMC5qcGchttps://placehold.co/400x200/ff9f1c/000000?text=Panambur+Sunset" 
    img:"https://imgs.search.brave.com/COd96LME8ldCpyR1dyEvGDZjqf9rr0LZYw8v2G0zTPQ/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly93d3cu/aXRzbGlmZS5pbi93/cC1jb250ZW50L2dh/bGxlcnkvdHJhdmVs/LXVkdXBpLW1hbmdh/bG9yZS9jYWNoZS90/cmF2ZWwtcGFuYW1i/dXItYmVhY2gtMi5q/cGctbmdnaWQwNTEy/MzI2LW5nZzBkeW4t/NjAweDQ1MHgxMDAt/MDBmMHcwMTBjMDEx/cjExMGYxMTByMDEw/dDAxMC5qcGc"
    },
    {
        id: 2,
        title: "A Foodie's Guide to Mangalore Cuisine",
        author: "Swayam S Rai (Blogger)",
        date: "Nov 15 2025",
        excerpt: "From Fish Thali to Neer Dosa, this is a comprehensive, must-try list for every traveler visiting Kudla. We cover the best places for authentic Goli Baje and Mangalorean Chicken Sukka...",
        category: "Cuisine",
        img: "https://imgs.search.brave.com/EUvGDbFwBCJswcIvDfk2VAKVcEKVYhgo-gAp3QZxrTE/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly93d3cu/c3Rvcmllc2J5c291/bXlhLmNvbS93cC1j/b250ZW50L3VwbG9h/ZHMvMjAyMS8wMy9N/YW5nYWxvcmUtbm9u/LXZlZy1wbGF0dGVy/LW1pbi5qcGc"
    },
    {
        id: 3,
        title: "Kadri Temple: History and Architecture",
        author: "Swayam S Rai (Blogger)",
        date: "Nov 15 2025",
        excerpt: "Exploring the 1000-year history behind the majestic Kadri Manjunath Temple, its unique blend of Buddhist and Hindu architecture, and the annual festival schedule you shouldn't miss...",
        category: "Culture",
        img: "https://imgs.search.brave.com/a2vB7o_i9ONtbcQW6eExMH3TQbYsKeS45RJDFKQz488/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly90ZW1w/bGUueWF0cmFkaGFt/Lm9yZy9wdWJsaWMv/UHJvZHVjdC90ZW1w/bGUvdGVtcGxlX3ZD/dVdMa3FwXzIwMjUw/NTI0MTUxMTMzMC5q/cGc"
    },
    {
        id: 4,
        title: "Hidden Gems of Karkala",
        author: "Swayam S Rai (Blogger)",
        date: "Nov 15 2025",
        excerpt: "A day trip outside the city limits to the lesser-known, stunning monolithic structures and peaceful temples of Karkala, a perfect escape from the city bustle...",
        category: "Guides & Tips",
        img: "https://imgs.search.brave.com/XUi1IpRi5LpmB8E1VRMftXquhJnR0gTizQDNUgMNRdQ/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly93d3cu/aG9saWRpZnkuY29t/L2ltYWdlcy9jbXN1/cGxvYWRzL3NxdWFy/ZS9rYXJrYWxhLWdv/bWF0ZXNod2FyYV8y/MDIwMDYxODIwMjUx/NS5qcGc"
    },
];

const destinationsData = [
    {
        name: "St. Aloysius Chapel",
        description: "Known for its stunning frescos that rival the Sistine Chapel, this historical site is a must-visit for art and history lovers.",
        img: "https://imgs.search.brave.com/9m8ryB85psg0H3SXc8SFPGWtkVxQzlU7AXfgZw4cjhA/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9tZWRp/YS5nZXR0eWltYWdl/cy5jb20vaWQvMTY2/OTUxNTQxOS9waG90/by9zdC1hbG95c2l1/cy1jaGFwZWwtaW4t/bWFuZ2Fsb3JlLmpw/Zz9zPTYxMng2MTIm/dz0wJms9MjAmYz1w/WEhNZFBWYjRPNVdN/MUZBdGZ0RXd3VUJk/dHNJMXRMZWFCd0U3/OFBBa28wPQ",
        link: "post-detail.html?id=3" 
    },
    {
        name: "Pilikula Nisargadhama",
        description: "A large eco-park complex featuring a zoo, botanical garden, and a science center. A perfect place for a family day out.",
        img: "https://imgs.search.brave.com/H-L947RgoAHqdpR_l7hyHvgl7WGd03or73xYqgScvvo/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly93d3cu/a2FybmF0YWthdHJh/dmVsZ3VpZGUuaW4v/YWRtaW4vaW1nYWwv/cGlsaWt1bGElMjBu/aXNhcmdhZGhhbWEu/anBn",
        link: "post-detail.html?id=1"
    },
    {
        name: "Sultan Battery",
        description: "A historical watchtower offering scenic views of the Gurupura River. Great for a quick history lesson and sunset viewing.",
        img: "https://imgs.search.brave.com/zOAXrg86mZznmSMMCf4-TwcpoYSwSBGbyGJqRRYhxO4/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9oYmxp/bWcubW10Y2RuLmNv/bS9jb250ZW50L2h1/YmJsZS9pbWcvbWFu/Z2xvcmUvbW10L2Fj/dGl2aXRpZXMvbV9T/dWx0YW4lMjBCYXR0/ZXJ5LTNfbF8zNjBf/NjQwLmpwZw",
        link: "post-detail.html?id=2"
    }
];


// --- Core Rendering Function (Simplified) ---
/**
 * Renders HTML cards into a specified container from a data array.
 * @param {string} containerId - The ID of the HTML element to render into.
 * @param {Array<Object>} dataArray - The array of data (posts or destinations).
 * @param {boolean} isPost - True if rendering a blog post.
 */
function renderCards(containerId, dataArray, isPost) {
    const container = document.getElementById(containerId);
    if (!container) return; 

    if (dataArray.length === 0) {
        container.innerHTML = '<p style="padding: 20px; color: #cc0000;">No results found. Try a different search term or category.</p>';
        return;
    }

    container.innerHTML = dataArray.map(item => {
        // Now using item.img directly as it's a full URL
        const link = isPost ? `post-detail.html?id=${item.id}` : item.link;

        return `
            <div class="card">
                <img src="${item.img}" alt="${item.title || item.name}">
                <div class="card-content">
                    <h3><a href="${link}">${item.title || item.name}</a></h3>
                    ${isPost ? `<p class="meta">By ${item.author} | ${item.date}</p>` : ''}
                    <p>${item.excerpt || item.description}</p>
                    <a href="${link}" style="display: block; margin-top: 10px; font-weight: bold;">View Details &rarr;</a>
                </div>
            </div>
        `;
    }).join('');
}


// --- Execution on DOM Load ---
document.addEventListener('DOMContentLoaded', () => {

    // --- Logic for Home Page (index.html) ---
    if (document.getElementById('featured-posts')) {
        renderCards('featured-posts', postsData.slice(0, 3), true);
    }
    
    if (document.getElementById('popular-destinations')) {
        renderCards('popular-destinations', destinationsData, false);
    }


    // --- Logic for Blog Listing Page (blog.html) ---
    const blogListContainer = document.getElementById('blog-list');
    const searchInput = document.getElementById('search-input');

    if (blogListContainer) {
        const filterAndRender = (searchTerm = '') => {
            const lowerSearchTerm = searchTerm.toLowerCase();
            const filteredPosts = postsData.filter(post =>
                post.title.toLowerCase().includes(lowerSearchTerm) ||
                post.author.toLowerCase().includes(lowerSearchTerm) ||
                post.excerpt.toLowerCase().includes(lowerSearchTerm) ||
                post.category.toLowerCase().includes(lowerSearchTerm)
            );
            renderCards('blog-list', filteredPosts, true);
        };
        
        filterAndRender();

        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                filterAndRender(e.target.value);
            });
        }
    }


    // --- Logic for Destinations Page (destinations.html) ---
    const destinationsContainer = document.getElementById('all-destinations');
    if (destinationsContainer) {
        renderCards('all-destinations', destinationsData, false);
    }
});